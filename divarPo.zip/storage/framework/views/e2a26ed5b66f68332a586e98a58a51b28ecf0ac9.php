<?php $__env->startSection('title'); ?>
   ورود
<?php $__env->stopSection(); ?>
<?php $__env->startSection('head_left_icon'); ?>
    <a href="<?php echo e(\Illuminate\Support\Facades\URL::previous()); ?>" class="material-icons mdc-icon-button bold-font btn-left-side" data-mdc-ripple-is-unbounded="true" style="color: black;margin-top: 7px;margin-right: 15px;position: absolute;left: 10px">arrow_back</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container" dir="rtl">
        <div style="direction: rtl;width: 100%;height: auto;padding: 30px;display: inline-block;background-color: white;border: 1px solid #e0e0e0;box-shadow: 0px 0px 8px #e0e0e0">
            <h2 class="bold-font">فرم ورود</h2>
            <hr>
            <?php if(session('status') == 'error'): ?>
            <div style="text-align: center;height: auto;background-color: #b91d19; line-height: 51px;padding: 10px;   color: #856404;
    background-color: #fff3cd;border-radius: 150rem;
    border-color: #ffeeba;">
                <span><?php echo e(session('message')); ?></span>
            </div>
            <?php endif; ?>
            <form action="<?php echo e(route('signin')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mdc-text-field text-field mdc-text-field--outlined mdc-text-field--with-leading-icon col-lg-5 col-md-5 col-sm-12 col-xs-12 buti-border" style="<?php if ($errors->has('phone')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('phone'); ?> border-right: 5px solid #ef5661!important; <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>;height: 48px;float: right;margin-top: 10px">
                    <i class="material-icons mdc-text-field__icon">phone</i>
                    <input value="<?php echo e(old('phone')); ?>" name="phone" type="text" style="font-size: 16px;margin-right: 30px;border: none;width: 100%" class="my-font" placeholder="شماره تلفن خود را وارد کنید..." aria-describedby="text-field-outlined-leading-helper-text">
                    <div class="mdc-notched-outline mdc-notched-outline--upgraded">
                        <div class="mdc-notched-outline__leading">
                        </div>
                        <div class="mdc-notched-outline__notch" style="">
                            
                        </div>
                        <div class="mdc-notched-outline__trailing">

                        </div>
                    </div>
                </div>
                <div class="mdc-text-field text-field mdc-text-field--outlined mdc-text-field--with-leading-icon col-lg-5 col-md-5 col-sm-12 col-xs-12 buti-border form-set" style="<?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> border-right: 5px solid #ef5661!important; <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>;height: 48px;float: right;margin-top: 10px">
                    <i class="material-icons mdc-text-field__icon">lock</i>
                    <input type="password" name="password" style="font-size: 16px;margin-right: 30px;border: none;width: 100%" class="my-font" placeholder="رمز عبور مورد نظر خود را وارد کنید..." aria-describedby="text-field-outlined-leading-helper-text">
                    <div class="mdc-notched-outline mdc-notched-outline--upgraded">
                        <div class="mdc-notched-outline__leading">

                        </div>
                        <div class="mdc-notched-outline__notch" style="">
                            
                        </div>
                        <div class="mdc-notched-outline__trailing">

                        </div>
                    </div>
                </div>
                <div class="mdc-text-field mdc-text-field--textarea col-lg-5 col-md-5 col-sm-12 col-xs-12 form-set" style="margin-top: 20px;float: right;justify-content:space-around">
                    <button type="submit" style="width: 199px;height: 45px;color: white;font-size: 16px;border: none;border-radius: 5px;font-weight: bold" class="blue-shadow blue-color-back my-font btn-ripple mdc-ripple-surface">ورود</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>













<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alihamrani/Desktop/php/divarPo/resources/views/auth/login.blade.php ENDPATH**/ ?>