<?php $__env->startSection('title'); ?>
    تایید شماره تلفن
<?php $__env->stopSection(); ?>
<?php $__env->startSection('head_left_icon'); ?>
    <a href="<?php echo e(\Illuminate\Support\Facades\URL::previous()); ?>" class="material-icons mdc-icon-button bold-font btn-left-side" data-mdc-ripple-is-unbounded="true" style="color: black;margin-top: 7px;margin-right: 15px;position: absolute;left: 10px">arrow_back</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container" dir="rtl">
        <div style="direction: rtl;width: 100%;height: auto;padding: 30px;display: inline-block;background-color: white;border: 1px solid #e0e0e0;box-shadow: 0px 0px 8px #e0e0e0">
            <h2 class="bold-font">تایید شماره تلفن</h2>
            <span style="font-size: 12px;color: #636b6f">کد فعاسازی به شماره شما ارسال خواهد شد.</span>
            <br>
            <span style="font-size: 12px;color: #636b6f">برای فعالسازی اکانت خود کد ارسال شده را در زیر وارد کنید.</span>
            <hr>
            <form action="#" method="GET">
                <?php echo csrf_field(); ?>
                <div class="mdc-text-field text-field mdc-text-field--outlined mdc-text-field--with-leading-icon col-lg-5 col-md-5 col-sm-12 col-xs-12 buti-border" style="height: 48px;float: right;margin-top: 10px">
                    <i class="material-icons mdc-text-field__icon">mobile</i>
                    <input type="number" style="font-size: 16px;margin-right: 30px;border: none;width: 100%" class="my-font" placeholder="کد فعالسازی" aria-describedby="text-field-outlined-leading-helper-text">
                    <div class="mdc-notched-outline mdc-notched-outline--upgraded">
                        <div class="mdc-notched-outline__leading">

                        </div>
                        <div class="mdc-notched-outline__notch" style="">
                            
                        </div>
                        <div class="mdc-notched-outline__trailing">

                        </div>
                    </div>
                </div>
                <div class="mdc-text-field mdc-text-field--textarea col-lg-5 col-md-5 col-sm-12 col-xs-12 form-set" style="margin-top: 20px;float: right;justify-content:space-around">
                    <button type="submit" style="width: 199px;height: 45px;color: white;font-size: 16px;border: none;border-radius: 5px;font-weight: bold" class="blue-shadow blue-color-back my-font btn-ripple mdc-ripple-surface">تایید</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alihamrani/Desktop/php/divarPo/resources/views/auth/verification.blade.php ENDPATH**/ ?>