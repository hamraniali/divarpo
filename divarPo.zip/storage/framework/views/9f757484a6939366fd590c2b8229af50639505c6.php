<?php $__env->startSection('title'); ?>
    <?php
          $city = \App\City::find($advertising->city_id);
          $district = \App\District::find($advertising->district_id);
    ?>
    <?php echo e($advertising->name . ' - ' . $city->name . ' - ' . $district->name); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('head_left_icon'); ?>
    <a href="<?php echo e(\Illuminate\Support\Facades\URL::previous()); ?>" class="material-icons mdc-icon-button bold-font btn-left-side" data-mdc-ripple-is-unbounded="true" style="color: black;margin-top: 7px;margin-right: 15px;position: absolute;left: 10px">arrow_back</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo e($advertising); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/alihamrani/Desktop/php/divarPo/resources/views/pages/advertising.blade.php ENDPATH**/ ?>